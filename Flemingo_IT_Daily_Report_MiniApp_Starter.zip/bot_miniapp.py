
import os
import logging
import json
from telegram.ext import CallbackQueryHandler
from dotenv import load_dotenv
from supabase import create_client
from datetime import datetime, date, timezone
from telegram import (
    Update,
    ReplyKeyboardMarkup,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InputFile,
    WebAppInfo,
    KeyboardButton
)
from telegram.ext import (
    Application,
    CommandHandler,
    ConversationHandler,
    MessageHandler,
    ContextTypes,
    filters,
)
from io import BytesIO
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle
)



load_dotenv()

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
ADMIN_ID = os.getenv("ADMIN_TELEGRAM_ID")
WEBAPP_URL = os.getenv("WEBAPP_URL", "https://YOUR-HTTPS-WEBAPP-URL")

logging.basicConfig(level=logging.INFO)
logging.getLogger("httpx").setLevel(logging.WARNING)

(
    DUTY_DATE,
    SHIFT_SELECTION,
    START_TIME,
    END_TIME,
    ACTIVITY_DESCRIPTION,
    ACTIVITY_STATUS,
    ACTIVITY_REASON,
    ACTIVITY_NEXT_ACTION,
    ACTIVITY_MORE,
    PROBLEMS,
    PENDING,
    COMMENTS,
    CONFIRM,
) = range(13)

SERVICE_CHECKS = 13
REPORT_LOCATION = 14
SEARCH_REPORT_QUERY = 99

def get_db():
    return create_client(SUPABASE_URL, SUPABASE_KEY)


# ==========================================
# BOT SETTINGS MANAGEMENT
# ==========================================

def get_bot_setting(setting_key, default=None):
    try:
        db = get_db()
        response = (
            db.table("bot_settings")
            .select("setting_value")
            .eq("setting_key", setting_key)
            .execute()
        )

        if response.data:
            return response.data[0]["setting_value"]

        return default

    except Exception as e:
        print(f"Settings retrieval error: {e}")
        return default


def log_admin_action(admin_id, action, details=None):
    try:
        db = get_db()
        db.table("admin_activity_logs").insert({
            "actor_telegram_id": int(admin_id),
            "action": action,
            "details": details or {}
        }).execute()

    except Exception as e:
        print(f"Activity log error: {e}")


def save_bot_setting(setting_key, setting_value, admin_id):
    try:
        db = get_db()
        db.table("bot_settings").upsert({
            "setting_key": setting_key,
            "setting_value": setting_value,
            "updated_by": int(admin_id),
            "updated_at": datetime.now(timezone.utc).isoformat()
        }).execute()

        log_admin_action(
            admin_id,
            "UPDATED_SETTING",
            {"setting_key": setting_key}
        )

        return True

    except Exception as e:
        print(f"Settings save error: {e}")
        return False


def get_bot_branding():
    return get_bot_setting("branding", {
        "bot_name": "Flemingo IT Daily Report",
        "subtitle": "Daily IT Service Desk",
        "footer": "Internal IT Operations | Authorized Access Only",
        "banner_url": "",
        "theme": "dark_technology"
    })
def get_welcome_messages():
    return get_bot_setting(
        "welcome_messages",
        {
            "new_user": (
                "Welcome to Flemingo IT Daily Report!\n\n"
                "Your daily IT service desk reporting system."
            ),
            "approved_user": (
                "Welcome back!\n\n"
                "Manage your daily IT operations and submit your reports."
            ),
            "admin": (
                "Welcome, Administrator!\n\n"
                "Manage employees, review reports and monitor IT operations."
            )
        }
    )


DEFAULT_SHIFTS = [
    {
        "name": "Morning Shift",
        "start_time": "06:00",
        "end_time": "15:00",
        "enabled": True
    },
    {
        "name": "Afternoon Shift",
        "start_time": "15:00",
        "end_time": "23:00",
        "enabled": True
    },
]

def get_shift_settings():
    settings = get_bot_setting(
        "duty_shifts",
        {"items": DEFAULT_SHIFTS.copy()}
    )

    if isinstance(settings, list):
        items = settings
    elif isinstance(settings, dict):
        items = settings.get("items", DEFAULT_SHIFTS.copy())
    else:
        items = DEFAULT_SHIFTS.copy()

    normalized = []

    for shift in items:
        item = dict(shift)
        name = item.get("name", "")

        if name.lower() == "morning shift":
            item.setdefault("start_time", "06:00")
            item.setdefault("end_time", "15:00")

        elif name.lower() == "afternoon shift":
            item.setdefault("start_time", "15:00")
            item.setdefault("end_time", "23:00")

        else:
            item.setdefault("start_time", "09:00")
            item.setdefault("end_time", "17:00")

        normalized.append(item)

    return normalized


def get_active_shifts():
    return [
        shift
        for shift in get_shift_settings()
        if shift.get("enabled", True)
        and shift.get("name", "").lower() != "night shift"
    ]


def save_shift_settings(items, admin_id):
    return save_bot_setting(
        "duty_shifts",
        {"items": items},
        admin_id
    )


def shift_keyboard():
    rows = []

    for index, shift in enumerate(get_shift_settings()):
        status = "🟢" if shift.get("enabled", True) else "🔴"

        rows.append([
            InlineKeyboardButton(
                f"{status} {shift['name']}",
                callback_data=f"shift_manage:{index}"
            )
        ])

    rows.append([
        InlineKeyboardButton(
            "➕ Add New Shift",
            callback_data="shift_add"
        )
    ])

    rows.append([
        InlineKeyboardButton(
            "⬅️ Back to Settings",
            callback_data="admin_settings_back"
        )
    ])

    return InlineKeyboardMarkup(rows)

def employee_shift_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                shift["name"],
                callback_data=f"duty_shift:{index}"
            )
        ]
        for index, shift in enumerate(get_active_shifts())
    ])

async def show_shift_manager(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer("Unauthorized.", show_alert=True)
        return

    await query.answer()

    await query.edit_message_text(
        "🕒 DUTY SHIFT MANAGEMENT\n\n"
        "Create and manage employee duty shifts.\n"
        "🟢 Active | 🔴 Disabled",
        reply_markup=shift_keyboard()
    )


async def shift_add(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer("Unauthorized.", show_alert=True)
        return

    await query.answer()

    context.user_data["shift_action"] = "add_name"

    await query.message.reply_text(
        "Enter the new shift name:"
    )



async def shift_manage(update, context):
    query = update.callback_query

    if not is_admin_user(update.effective_user.id):
        await query.answer("Access denied.", show_alert=True)
        return

    await query.answer()

    try:
        index = int(query.data.split(":")[1])
    except (ValueError, IndexError):
        await query.message.reply_text("Invalid shift selection.")
        return

    items = get_shift_settings()

    if index < 0 or index >= len(items):
        await query.message.reply_text("Shift not found.")
        return

    shift = items[index]

    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "✏️ Rename",
                callback_data=f"shift_rename:{index}"
            )
        ],
        [
            InlineKeyboardButton(
                "🕒 Set Shift Hours",
                callback_data=f"shift_times:{index}"
            )
        ],
        [
            InlineKeyboardButton(
                "🔄 Enable / Disable",
                callback_data=f"shift_toggle:{index}"
            )
        ],
        [
            InlineKeyboardButton(
                "🗑 Delete",
                callback_data=f"shift_delete:{index}"
            )
        ],
        [
            InlineKeyboardButton(
                "⬅️ Back",
                callback_data="shift_back"
            )
        ]
    ])

    await query.edit_message_text(
        f"⚙️ Manage Shift\n\n"
        f"Name: {shift['name']}\n"
        f"Start: {shift.get('start_time', 'Not set')}\n"
        f"End: {shift.get('end_time', 'Not set')}\n"
        f"Status: {'Enabled' if shift.get('enabled', True) else 'Disabled'}",
        reply_markup=keyboard
    )



async def shift_change(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer("Unauthorized.", show_alert=True)
        return

    await query.answer()

    action, index_text = query.data.split(":")
    index = int(index_text)

    items = get_shift_settings()

    if index < 0 or index >= len(items):
        await query.edit_message_text("Shift not found.")
        return

    if action == "shift_rename":
        context.user_data["shift_action"] = "rename"
        context.user_data["shift_index"] = index

        await query.message.reply_text(
            f"Enter the new name for {items[index]['name']}:"
        )
        return

    if action == "shift_times":
        context.user_data["shift_action"] = "edit_start"
        context.user_data["shift_index"] = index

        await query.message.reply_text(
            f"Enter the new start time for {items[index]['name']}.\n"
            "Use HH:MM, for example 06:00."
        )
        return

    if action == "shift_toggle":
        items[index]["enabled"] = not items[index].get("enabled", True)

    elif action == "shift_delete":
        items.pop(index)

    if save_shift_settings(items, query.from_user.id):
        await query.edit_message_text(
            "Shift settings updated.",
            reply_markup=shift_keyboard()
        )
    else:
        await query.edit_message_text(
            "Unable to save shift settings."
        )


async def shift_text_input(update, context):
    action = context.user_data.get("shift_action")

    if not action or not update.message:
        return

    if not is_admin_user(update.effective_user.id):
        context.user_data.pop("shift_action", None)
        await update.message.reply_text("Unauthorized.")
        return

    value = update.message.text.strip()

    def valid_time(text):
        try:
            datetime.strptime(text, "%H:%M")
            return True
        except ValueError:
            return False

    items = get_shift_settings()
    admin_id = update.effective_user.id

    if action in ("add_start", "add_end", "edit_start", "edit_end"):
        if not valid_time(value):
            await update.message.reply_text(
                "Invalid time. Use HH:MM, for example 06:00."
            )
            return

    if action == "add_name":
        if not value or len(value) > 50:
            await update.message.reply_text(
                "Enter a shift name between 1 and 50 characters."
            )
            return

        if any(x["name"].lower() == value.lower() for x in items):
            await update.message.reply_text(
                "This shift already exists."
            )
            return

        context.user_data["new_shift"] = {
            "name": value,
            "enabled": True
        }

        context.user_data["shift_action"] = "add_start"

        await update.message.reply_text(
            "Enter the shift starting time (HH:MM)."
        )
        return

    elif action == "add_start":
        context.user_data["new_shift"]["start_time"] = value
        context.user_data["shift_action"] = "add_end"

        await update.message.reply_text(
            "Enter the shift ending time (HH:MM)."
        )
        return

    elif action == "add_end":
        new_shift = context.user_data["new_shift"]
        new_shift["end_time"] = value

        items.append(new_shift)

    elif action == "rename":
        index = context.user_data.get("shift_index")

        if not value or len(value) > 50:
            await update.message.reply_text(
                "Enter a name between 1 and 50 characters."
            )
            return

        if any(
            x["name"].lower() == value.lower()
            and i != index
            for i, x in enumerate(items)
        ):
            await update.message.reply_text(
                "This shift already exists."
            )
            return

        if index is None or index < 0 or index >= len(items):
            await update.message.reply_text("Shift not found.")
            return

        items[index]["name"] = value

    elif action == "edit_start":
        context.user_data["pending_shift_start"] = value
        context.user_data["shift_action"] = "edit_end"

        await update.message.reply_text(
            "Enter the new shift ending time (HH:MM)."
        )
        return

    elif action == "edit_end":
        index = context.user_data.get("shift_index")

        if index is None or index < 0 or index >= len(items):
            await update.message.reply_text("Shift not found.")
            return

        items[index]["start_time"] = context.user_data.pop(
            "pending_shift_start"
        )
        items[index]["end_time"] = value

    else:
        await update.message.reply_text("Invalid shift action.")
        return

    if save_shift_settings(items, admin_id):
        for key in (
            "shift_action",
            "shift_index",
            "new_shift",
            "pending_shift_start"
        ):
            context.user_data.pop(key, None)

        await update.message.reply_text(
            "Shift settings saved successfully.",
            reply_markup=shift_keyboard()
        )
    else:
        await update.message.reply_text(
            "Unable to save shift settings."
        )

def get_employee(telegram_id):
    result = (
        get_db().table("employees")
        .select("*")
        .eq("telegram_id", telegram_id)
        .limit(1)
        .execute()
    )
    return result.data[0] if result.data else None


async def my_reports(update, context):
    user = update.effective_user
    employee = get_employee(user.id) if user else None

    if not employee or not employee.get("active"):
        await update.message.reply_text("Your account is not approved.")
        return

    try:
        result = (
            get_db().table("daily_reports")
            .select("id, report_date, duty_start, duty_end, shift, report_location, review_status")
            .eq("employee_id", employee["id"])
            .order("report_date", desc=True)
            .limit(20)
            .execute()
        )

        reports = result.data or []

        if not reports:
            await update.message.reply_text("You have not submitted any reports yet.")
            return

        rows = []

        for report in reports:
            report_id = report["id"]
            status = report.get("review_status") or "pending"

            rows.append([
                InlineKeyboardButton(
                    f"📄 {report.get('report_date')} | {status.title()}",
                    callback_data=f"my_report:{report_id}"
                )
            ])

        rows.append([
            InlineKeyboardButton("🔄 Refresh", callback_data="my_reports")
        ])

        await update.message.reply_text(
            f"📁 MY REPORTS\n\nShowing {len(reports)} recent reports.",
            reply_markup=InlineKeyboardMarkup(rows)
        )

    except Exception:
        logging.exception("My Reports error")
        await update.message.reply_text("Unable to load your reports.")


async def my_reports_refresh(update, context):
    query = update.callback_query
    await query.answer()

    user = query.from_user
    employee = get_employee(user.id)

    if not employee or not employee.get("active"):
        await query.edit_message_text("Your account is not approved.")
        return

    try:
        result = (
            get_db().table("daily_reports")
            .select("id, report_date, review_status")
            .eq("employee_id", employee["id"])
            .order("report_date", desc=True)
            .limit(20)
            .execute()
        )

        reports = result.data or []
        rows = []

        for report in reports:
            rows.append([
                InlineKeyboardButton(
                    f"📄 {report['report_date']} | "
                    f"{(report.get('review_status') or 'pending').title()}",
                    callback_data=f"my_report:{report['id']}"
                )
            ])

        rows.append([
            InlineKeyboardButton("🔄 Refresh", callback_data="my_reports")
        ])

        await query.edit_message_text(
            f"📁 MY REPORTS\n\nShowing {len(reports)} recent reports.",
            reply_markup=InlineKeyboardMarkup(rows)
        )

    except Exception:
        logging.exception("My Reports refresh error")
        await query.edit_message_text("Unable to refresh your reports.")


async def my_report_detail(update, context):
    query = update.callback_query
    await query.answer()

    employee = get_employee(query.from_user.id)

    if not employee or not employee.get("active"):
        await query.edit_message_text("Your account is not approved.")
        return

    try:
        report_id = int(query.data.split(":")[1])

        result = (
            get_db().table("daily_reports")
            .select("*")
            .eq("id", report_id)
            .eq("employee_id", employee["id"])
            .limit(1)
            .execute()
        )

        if not result.data:
            await query.edit_message_text("Report not found or access denied.")
            return

        report = result.data[0]

        message = (
            "📄 DAILY IT REPORT\n\n"
            f"Report ID: {report.get('id')}\n"
            f"Date: {report.get('report_date')}\n"
            f"Shift: {report.get('shift') or 'N/A'}\n"
            f"Location: {report.get('report_location') or 'N/A'}\n"
            f"Duty: {report.get('duty_start')} - {report.get('duty_end')}\n"
            f"Review status: {(report.get('review_status') or 'pending').title()}\n\n"
            f"Activities:\n{report.get('activities') or 'None'}\n\n"
            f"Problems:\n{report.get('problems') or 'None'}\n\n"
            f"Pending tasks:\n{report.get('pending_tasks') or 'None'}\n\n"
            f"Comments:\n{report.get('comments') or 'None'}"
        )

        await query.edit_message_text(
            message[:4000],
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("⬅️ Back to My Reports", callback_data="my_reports")
            ]])
        )

    except Exception:
        logging.exception("Report detail error")
        await query.edit_message_text("Unable to open this report.")


async def show_user_dashboard(chat_id, user, context):
    tid = user.id
    name = user.full_name

    branding = get_bot_branding()
    welcome_messages = get_welcome_messages()

    bot_name = branding.get(
        "bot_name", "Flemingo IT Daily Report"
    )
    subtitle = branding.get(
        "subtitle", "Daily IT Service Desk"
    )
    footer = branding.get(
        "footer",
        "Internal IT Operations | Authorized Access Only"
    )

    employee = get_employee(tid)

    if str(tid) == str(ADMIN_ID) or (
        employee
        and employee.get("role") == "admin"
        and employee.get("active") is True
    ):
        admin_message = welcome_messages.get(
            "admin", "Welcome, Administrator!"
        )

        keyboard = [
            [KeyboardButton("🚀 Open IT Service Desk", web_app=WebAppInfo(url=WEBAPP_URL))],
            ["📋 Admin Approval"],
            ["🔎 Search Reports"],
            ["⚙️ Admin Settings"],
        ]

        await context.bot.send_message(
            chat_id=chat_id,
            text=(
                f"🔷 {bot_name}\n"
                f"{subtitle}\n\n"
                f"👋 {admin_message}\n\n"
                f"👤 Administrator: {name}\n"
                f"🟢 System Status: Online\n\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"⚙️ ADMIN DASHBOARD\n"
                f"━━━━━━━━━━━━━━━━━━\n\n"
                f"Select an option below.\n\n"
                f"🔐 {footer}"
            ),
            reply_markup=ReplyKeyboardMarkup(
                keyboard,
                resize_keyboard=True,
            ),
        )
        return

    employee_message = welcome_messages.get(
        "employee",
        "Welcome! Manage your daily IT duties here."
    )

    keyboard = [
        [KeyboardButton("🚀 Open IT Service Desk", web_app=WebAppInfo(url=WEBAPP_URL))],
        ["📝 Start Daily Report"],
        ["📁 My Reports"],
        ["📚 IT Guidelines"],
        ["👤 My Profile"],
    ]

    await context.bot.send_message(
        chat_id=chat_id,
        text=(
            f"🔷 {bot_name}\n"
            f"{subtitle}\n\n"
            f"👋 {employee_message}\n\n"
            f"👤 Employee: {name}\n"
            f"🟢 Account Status: Active\n\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"💻 EMPLOYEE DASHBOARD\n"
            f"━━━━━━━━━━━━━━━━━━\n\n"
            f"Select an option below.\n\n"
            f"🔐 {footer}"
        ),
        reply_markup=ReplyKeyboardMarkup(
            keyboard,
            resize_keyboard=True,
        ),
    )

PROFILE_FIELDS = {
    "full_name": "Full name",
    "job_title": "Job title",
    "work_location": "Work location",
    "office": "Office",
    "arrival_time": "Arrival time",
    "departure_time": "Departure time",
}


def profile_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✏️ Full Name", callback_data="profile_edit:full_name")],
        [InlineKeyboardButton("✏️ Job Title", callback_data="profile_edit:job_title")],
        [InlineKeyboardButton("✏️ Work Location", callback_data="profile_edit:work_location")],
        [InlineKeyboardButton("✏️ Office", callback_data="profile_edit:office")],
        [InlineKeyboardButton("🕒 Arrival Time", callback_data="profile_edit:arrival_time")],
        [InlineKeyboardButton("🕒 Departure Time", callback_data="profile_edit:departure_time")],
    ])


async def show_profile(update, context):
    user = update.effective_user
    employee = get_employee(user.id) if user else None

    if not employee or not employee.get("active"):
        await update.message.reply_text("Your account is not approved.")
        return

    text = (
        "👤 MY PROFILE\n\n"
        f"Name: {employee.get('full_name') or 'Not set'}\n"
        f"Job title: {employee.get('job_title') or 'Not set'}\n"
        f"Work location: {employee.get('work_location') or 'Not set'}\n"
        f"Office: {employee.get('office') or 'Not set'}\n"
        f"Arrival: {employee.get('arrival_time') or 'Not set'}\n"
        f"Departure: {employee.get('departure_time') or 'Not set'}\n\n"
        "Select a field to update:"
    )

    await update.message.reply_text(text, reply_markup=profile_keyboard())


async def profile_edit_callback(update, context):
    query = update.callback_query
    await query.answer()

    employee = get_employee(query.from_user.id)

    if not employee or not employee.get("active"):
        await query.edit_message_text("Your account is not approved.")
        return

    field = query.data.split(":", 1)[1]

    if field not in PROFILE_FIELDS:
        await query.edit_message_text("Invalid profile field.")
        return

    context.user_data["profile_action"] = field

    await query.message.reply_text(
        f"Enter your {PROFILE_FIELDS[field]}.\n"
        "For time fields, use HH:MM, for example 06:00."
    )


async def profile_text_input(update, context):
    field = context.user_data.get("profile_action")

    if not field or not update.message:
        return

    user = update.effective_user
    employee = get_employee(user.id) if user else None

    if not employee or not employee.get("active"):
        context.user_data.pop("profile_action", None)
        await update.message.reply_text("Your account is not approved.")
        return

    value = update.message.text.strip()

    if not value or len(value) > 100:
        await update.message.reply_text("Enter a value between 1 and 100 characters.")
        return

    if field in ("arrival_time", "departure_time"):
        try:
            datetime.strptime(value, "%H:%M")
        except ValueError:
            await update.message.reply_text("Invalid time. Use HH:MM, for example 06:00.")
            return

    try:
        get_db().table("employees").update({
            field: value
        }).eq("id", employee["id"]).execute()

        context.user_data.pop("profile_action", None)

        await update.message.reply_text(
            f"Your {PROFILE_FIELDS[field]} was updated successfully."
        )

    except Exception:
        logging.exception("Profile update error")
        await update.message.reply_text("Unable to update your profile.")

 
async def show_guidelines(update, context):
    try:
        result = (
            get_db().table("it_guidelines")
            .select("id, title, category")
            .eq("is_published", True)
            .eq("is_active", True)
            .order("category")
            .execute()
        )

        guidelines = result.data or []

        if not guidelines:
            await update.message.reply_text("No IT guidelines are currently published.")
            return

        rows = []

        for item in guidelines:
            rows.append([
                InlineKeyboardButton(
                    f"📘 {item['category']}: {item['title']}",
                    callback_data=f"guideline_view:{item['id']}"
                )
            ])

        await update.message.reply_text(
            "📚 IT GUIDELINES\n\nSelect a guideline:",
            reply_markup=InlineKeyboardMarkup(rows)
        )

    except Exception:
        logging.exception("Guidelines loading error")
        await update.message.reply_text("Unable to load IT guidelines.")


async def guideline_view(update, context):
    query = update.callback_query
    await query.answer()

    try:
        guideline_id = int(query.data.split(":")[1])

        result = (
            get_db().table("it_guidelines")
            .select("*")
            .eq("id", guideline_id)
            .eq("is_published", True)
            .eq("is_active", True)
            .limit(1)
            .execute()
        )

        if not result.data:
            await query.edit_message_text("Guideline not found or unavailable.")
            return

        item = result.data[0]

        message = (
            f"📘 {item['title']}\n"
            f"Category: {item['category']}\n\n"
            f"{item['content']}"
        )

        await query.edit_message_text(
            message[:4000],
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("⬅️ Back", callback_data="guidelines_back")
            ]])
        )

    except Exception:
        logging.exception("Guideline view error")
        await query.edit_message_text("Unable to open this guideline.")


async def guidelines_back(update, context):
    query = update.callback_query
    await query.answer()

    try:
        result = (
            get_db().table("it_guidelines")
            .select("id, title, category")
            .eq("is_published", True)
            .eq("is_active", True)
            .order("category")
            .execute()
        )

        rows = [
            [InlineKeyboardButton(
                f"📘 {item['category']}: {item['title']}",
                callback_data=f"guideline_view:{item['id']}"
            )]
            for item in (result.data or [])
        ]

        await query.edit_message_text(
            "📚 IT GUIDELINES\n\nSelect a guideline:",
            reply_markup=InlineKeyboardMarkup(rows) if rows else None
        )

    except Exception:
        logging.exception("Guidelines navigation error")
        await query.edit_message_text("Unable to load guidelines.")


def guideline_admin_keyboard():
    result = (
        get_db().table("it_guidelines")
        .select("id, title, is_published, is_active")
        .order("id", desc=True)
        .execute()
    )

    rows = []

    for item in result.data or []:
        published = "Published" if item.get("is_published") else "Draft"
        active = "Active" if item.get("is_active") else "Disabled"

        rows.append([
            InlineKeyboardButton(
                f"{item['title']} | {published} | {active}",
                callback_data=f"guideline_manage:{item['id']}"
            )
        ])

    rows.append([
        InlineKeyboardButton("➕ Add Guideline", callback_data="guideline_add")
    ])

    rows.append([
        InlineKeyboardButton("⬅️ Back to Settings", callback_data="admin_settings_back")
    ])

    return InlineKeyboardMarkup(rows)


async def guideline_admin_menu(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer("Unauthorized.", show_alert=True)
        return

    await query.answer()

    try:
        await query.edit_message_text(
            "📚 IT GUIDELINES MANAGEMENT\n\n"
            "Select a guideline to manage or create a new one.",
            reply_markup=guideline_admin_keyboard()
        )
    except Exception:
        logging.exception("Guideline admin menu error")
        await query.message.reply_text("Unable to load guideline management.")


async def guideline_add(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer("Unauthorized.", show_alert=True)
        return

    await query.answer()

    context.user_data["guideline_action"] = "add_title"

    await query.message.reply_text("Enter the guideline title:")


async def guideline_manage(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer("Unauthorized.", show_alert=True)
        return

    await query.answer()

    guideline_id = int(query.data.split(":")[1])

    result = (
        get_db().table("it_guidelines")
        .select("*")
        .eq("id", guideline_id)
        .limit(1)
        .execute()
    )

    if not result.data:
        await query.edit_message_text("Guideline not found.")
        return

    item = result.data[0]

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("✏️ Edit Title", callback_data=f"guideline_edit:{guideline_id}:title")],
        [InlineKeyboardButton("✏️ Edit Category", callback_data=f"guideline_edit:{guideline_id}:category")],
        [InlineKeyboardButton("✏️ Edit Content", callback_data=f"guideline_edit:{guideline_id}:content")],
        [InlineKeyboardButton("🌐 Publish / Unpublish", callback_data=f"guideline_publish:{guideline_id}")],
        [InlineKeyboardButton("🔄 Enable / Disable", callback_data=f"guideline_active:{guideline_id}")],
        [InlineKeyboardButton("⬅️ Back", callback_data="guideline_admin")]
    ])

    await query.edit_message_text(
        f"📘 {item['title']}\n"
        f"Category: {item['category']}\n"
        f"Published: {item.get('is_published')}\n"
        f"Active: {item.get('is_active')}\n\n"
        "Choose an action:",
        reply_markup=keyboard
    )


async def guideline_edit_start(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer("Unauthorized.", show_alert=True)
        return

    await query.answer()

    _, guideline_id, field = query.data.split(":")

    if field not in ("title", "category", "content"):
        await query.message.reply_text("Invalid field.")
        return

    context.user_data["guideline_action"] = f"edit_{field}"
    context.user_data["guideline_id"] = int(guideline_id)

    await query.message.reply_text(f"Enter the new guideline {field}:")


async def guideline_publish_toggle(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer("Unauthorized.", show_alert=True)
        return

    await query.answer()

    guideline_id = int(query.data.split(":")[1])

    try:
        result = (
            get_db().table("it_guidelines")
            .select("is_published")
            .eq("id", guideline_id)
            .single()
            .execute()
        )

        new_value = not result.data["is_published"]

        get_db().table("it_guidelines").update({
            "is_published": new_value,
            "updated_by": query.from_user.id,
            "updated_at": datetime.now(timezone.utc).isoformat()
        }).eq("id", guideline_id).execute()

        await query.edit_message_text(
            "Guideline published." if new_value else "Guideline unpublished.",
            reply_markup=guideline_admin_keyboard()
        )

    except Exception:
        logging.exception("Guideline publish update error")
        await query.message.reply_text("Unable to update publication status.")


async def guideline_active_toggle(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer("Unauthorized.", show_alert=True)
        return

    await query.answer()

    guideline_id = int(query.data.split(":")[1])

    try:
        result = (
            get_db().table("it_guidelines")
            .select("is_active")
            .eq("id", guideline_id)
            .single()
            .execute()
        )

        new_value = not result.data["is_active"]

        get_db().table("it_guidelines").update({
            "is_active": new_value,
            "updated_by": query.from_user.id,
            "updated_at": datetime.now(timezone.utc).isoformat()
        }).eq("id", guideline_id).execute()

        await query.edit_message_text(
            "Guideline enabled." if new_value else "Guideline disabled.",
            reply_markup=guideline_admin_keyboard()
        )

    except Exception:
        logging.exception("Guideline active update error")
        await query.message.reply_text("Unable to update guideline status.")


async def guideline_text_input(update, context):
    action = context.user_data.get("guideline_action")

    if not action or not update.message:
        return

    if not is_admin_user(update.effective_user.id):
        context.user_data.pop("guideline_action", None)
        await update.message.reply_text("Unauthorized.")
        return

    value = update.message.text.strip()

    if not value or len(value) > 3500:
        await update.message.reply_text("Enter text between 1 and 3500 characters.")
        return

    try:
        db = get_db()

        if action == "add_title":
            context.user_data["new_guideline"] = {"title": value}
            context.user_data["guideline_action"] = "add_category"
            await update.message.reply_text("Enter the guideline category:")
            return

        if action == "add_category":
            context.user_data["new_guideline"]["category"] = value
            context.user_data["guideline_action"] = "add_content"
            await update.message.reply_text("Enter the full guideline content:")
            return

        if action == "add_content":
            item = context.user_data["new_guideline"]

            db.table("it_guidelines").insert({
                "title": item["title"],
                "category": item["category"],
                "content": value,
                "is_published": False,
                "is_active": True,
                "created_by": update.effective_user.id,
                "updated_by": update.effective_user.id
            }).execute()

            context.user_data.pop("new_guideline", None)
            context.user_data.pop("guideline_action", None)

            await update.message.reply_text(
                "Guideline created as a draft. Publish it from Manage IT Guidelines."
            )
            return

        if action.startswith("edit_"):
            field = action.replace("edit_", "")
            guideline_id = context.user_data.get("guideline_id")

            db.table("it_guidelines").update({
                field: value,
                "updated_by": update.effective_user.id,
                "updated_at": datetime.now(timezone.utc).isoformat()
            }).eq("id", guideline_id).execute()

            context.user_data.pop("guideline_action", None)
            context.user_data.pop("guideline_id", None)

            await update.message.reply_text(f"Guideline {field} updated.")
            return

    except Exception:
        logging.exception("Guideline text input error")
        await update.message.reply_text("Unable to save the guideline.")

async def send_start_announcement(chat_id, context):
    announcement = get_bot_setting(
        "start_announcement",
        {
            "enabled": False,
            "type": "text",
            "text": "",
            "photo_file_id": "",
            "animation_file_id": "",
            "caption": "",
        }
    )

    if not announcement.get("enabled", False):
        return False

    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "➡️ Continue to Dashboard",
                callback_data="announcement_continue",
            )
        ]
    ])

    announcement_type = announcement.get("type", "text")
    text = announcement.get("text", "")
    caption = announcement.get("caption", "")

    if announcement_type == "photo":
        photo_id = announcement.get("photo_file_id")

        if photo_id:
            await context.bot.send_photo(
                chat_id=chat_id,
                photo=photo_id,
                caption=caption or text or None,
                reply_markup=keyboard,
            )
            return True

    elif announcement_type == "animation":
        animation_id = announcement.get("animation_file_id")

        if animation_id:
            await context.bot.send_animation(
                chat_id=chat_id,
                animation=animation_id,
                caption=caption or text or None,
                reply_markup=keyboard,
            )
            return True

    if text:
        await context.bot.send_message(
            chat_id=chat_id,
            text=text,
            reply_markup=keyboard,
        )
        return True

    return False


def activity_more_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(
            "➕ Add another activity",
            callback_data="activity_more:add"
        )],
        [InlineKeyboardButton(
            "Finish checklist",
            callback_data="activity_more:finish"
        )],
    ])
def activity_status_keyboard():
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "✅ Completed",
                callback_data="activity_status:Completed"
            )
        ],
        [
            InlineKeyboardButton(
                "🔄 In Progress",
                callback_data="activity_status:In progress"
            )
        ],
        [
            InlineKeyboardButton(
                "⏳ Remaining",
                callback_data="activity_status:Remaining"
            )
        ]
    ])


async def activity_description(update, context):
    description = update.message.text.strip()

    if not description:
        await update.message.reply_text("Enter an activity description.")
        return ACTIVITY_DESCRIPTION

    context.user_data["current_activity"] = {
        "description": description,
        "status": None,
        "reason": None,
        "next_action": None,
    }

    await update.message.reply_text(
        "Select the status of this activity:",
        reply_markup=activity_status_keyboard(),
    )
    return ACTIVITY_STATUS



async def activity_status(update, context):
    query = update.callback_query
    await query.answer()

    status = query.data.split(":", 1)[1]


    if status not in ("Completed", "In progress", "Remaining"):
        await query.edit_message_text("Invalid status. Please try again.")
        return ACTIVITY_STATUS

    activity = context.user_data["current_activity"]
    activity["status"] = status

    if status == "Completed":
        activity["reason"] = None
        await query.edit_message_text(
            "Activity marked Completed.\n"
            "Enter the next action or follow-up, or type None."
        )
        return ACTIVITY_NEXT_ACTION

    await query.edit_message_text(
        f"Status: {status}\n"
        "Explain why this activity is unfinished."
    )
    return ACTIVITY_REASON


async def activity_reason(update, context):
    reason = update.message.text.strip()

    if not reason or reason.lower() == "none":
        await update.message.reply_text(
            "Please explain why this activity is unfinished."
        )
        return ACTIVITY_REASON

    context.user_data["current_activity"]["reason"] = reason

    await update.message.reply_text(
        "What is the next action needed to finish this activity?"
    )
    return ACTIVITY_NEXT_ACTION


async def activity_next_action(update, context):
    value = update.message.text.strip()

    if not value:
        await update.message.reply_text(
            "Enter the next action, or type None."
        )
        return ACTIVITY_NEXT_ACTION

    activity = context.user_data["current_activity"]
    activity["next_action"] = (
        None if value.lower() == "none" else value
    )

    context.user_data.setdefault("activities_checklist", []).append(activity)
    context.user_data.pop("current_activity", None)

    await update.message.reply_text(
        "Activity added.\nWould you like to add another activity "
        "or finish the checklist?",
        reply_markup=activity_more_keyboard(),
    )
    return ACTIVITY_MORE


async def activity_more(update, context):
    query = update.callback_query
    await query.answer()

    choice = query.data

    if choice == "activity_more:add":
        await query.edit_message_text("Enter the next IT activity.")
        return ACTIVITY_DESCRIPTION

    if choice == "activity_more:finish":
        activities = context.user_data.get("activities_checklist", [])

        if not activities:
            await query.edit_message_text(
                "Add at least one activity before finishing."
            )
            return ACTIVITY_DESCRIPTION

        context.user_data["report"]["activities"] = "\n".join(
            f"{i}. {a['description']} — {a['status']}"
            for i, a in enumerate(activities, start=1)
        )

        await query.edit_message_text(
            "Checklist complete. Now describe technical problems "
            "encountered, or type None."
        )
        return PROBLEMS

    await query.edit_message_text("Please choose an option.")
    return ACTIVITY_MORE

DEFAULT_SERVICE_OPTIONS = [
    "POS Terminals",
    "Fiscal Printers",
    "Barcode Scanners",
    "Network & Internet",
    "CCTV System",
    "VPN Connection",
    "Backup System",
    "Inventory System",
    "Email & User Access",
    "UPS & Power",
    "Attendance System",
    "Server & Database",
]


def get_service_options():
    settings = get_bot_setting(
        "service_checklist",
        {"items": [
            {"name": name, "enabled": True}
            for name in DEFAULT_SERVICE_OPTIONS
        ]}
    )

    return [
        item["name"]
        for item in settings.get("items", [])
        if item.get("enabled", True)
    ]





def service_checks_keyboard(selected):
    rows = []

    statuses = [
        ("ok", "🟢 Operational", "Operational"),
        ("issue", "🔴 Issue Found", "Issue Found"),
        ("maintenance", "🟠 Maintenance", "Under Maintenance"),
        ("na", "⚪ Not Applicable", "Not Applicable"),
    ]

    options = get_service_options()

    for index, name in enumerate(options):
        current_status = selected.get(name)

        rows.append([
            InlineKeyboardButton(
                f"━━ {index + 1:02d}. {name} ━━",
                callback_data=f"service_info:{index}"
            )
        ])

        buttons = []

        for code, label, full_name in statuses:
            mark = "✓ " if current_status == full_name else ""

            buttons.append(
                InlineKeyboardButton(
                    mark + label,
                    callback_data=f"service_status:{index}:{code}"
                )
            )

        rows.append(buttons[:2])
        rows.append(buttons[2:])

    rows.append([
        InlineKeyboardButton(
            "➡️ Continue to IT Activities",
            callback_data="service_status:continue"
        )
    ])

    return InlineKeyboardMarkup(rows)


def service_checklist_text(selected):
    options = get_service_options()
    total = len(options)

    completed = sum(1 for name in options if name in selected)
    operational = sum(
        1 for name in options
        if selected.get(name) == "Operational"
    )
    issues = sum(
        1 for name in options
        if selected.get(name) == "Issue Found"
    )
    maintenance = sum(
        1 for name in options
        if selected.get(name) == "Under Maintenance"
    )
    pending = total - completed

    percentage = int(completed / total * 100) if total else 0

    progress = int(percentage / 10)
    progress_bar = "🟩" * progress + "⬜" * (10 - progress)

    return (
        "🏢 FLEMINGO IT SERVICE DESK\n"
        "📋 DAILY SERVICE INSPECTION\n"
        "━━━━━━━━━━━━━━━━━━━━\n\n"
        f"📊 Progress: {completed}/{total} ({percentage}%)\n"
        f"{progress_bar}\n\n"
        f"🟢 Operational: {operational}\n"
        f"🔴 Issues: {issues}\n"
        f"🟠 Maintenance: {maintenance}\n"
        f"⬜ Pending: {pending}\n\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        "SELECT THE STATUS OF EACH SERVICE\n"
        "Choose one option under every service."
    )



async def service_checks_callback(update, context):
    query = update.callback_query

    available_options = get_service_options()
    selected = context.user_data.setdefault("service_checks", {})

    parts = query.data.split(":")

    status_map = {
        "ok": "Operational",
        "issue": "Issue Found",
        "maintenance": "Under Maintenance",
        "na": "Not Applicable",
    }

    # Continue
    if len(parts) == 2 and parts[1] == "continue":

        missing = [
            name for name in available_options
            if name not in selected
        ]

        if missing:
            await query.answer(
                f"{len(missing)} service(s) still need a status.",
                show_alert=True
            )
            return SERVICE_CHECKS

        await query.answer()

        context.user_data["report"]["service_checks"] = [
            {"name": name, "status": selected[name]}
            for name in available_options
        ]

        await query.edit_message_text(
            "✅ IT service checklist completed."
        )

        await query.message.reply_text(
            "STEP 3 — IT ACTIVITIES\n\n"
            "Enter your first IT activity.\n\n"
            "Example: Troubleshoot cashier POS printer."
        )

        return ACTIVITY_DESCRIPTION

    # Show service name
    if len(parts) == 2 and parts[0] == "service_info":

        try:
            index = int(parts[1])
            name = available_options[index]

            await query.answer(name, show_alert=True)

        except (ValueError, IndexError):
            await query.answer(
                "Service not found.",
                show_alert=True
            )

        return SERVICE_CHECKS

    # Save selected service status
    if len(parts) == 3 and parts[0] == "service_status":

        try:
            index = int(parts[1])
            code = parts[2]

            name = available_options[index]

            if code not in status_map:
                await query.answer(
                    "Invalid status.",
                    show_alert=True
                )
                return SERVICE_CHECKS

        except (ValueError, IndexError):
            await query.answer(
                "Invalid checklist selection.",
                show_alert=True
            )
            return SERVICE_CHECKS

        selected[name] = status_map[code]

        completed = len(selected)
        total = len(available_options)

        await query.answer("Status saved.")

        await query.edit_message_text(
            "STEP 2 — IT SERVICE CHECKLIST\n\n"
            "Select one status for each service.\n"
            f"Progress: {completed}/{total}",
            reply_markup=service_checks_keyboard(selected)
        )

        return SERVICE_CHECKS

    await query.answer()
    return SERVICE_CHECKS
async def report_start(update, context):
    user = update.effective_user

    if not user or not update.message:
        return ConversationHandler.END

    try:
        employee = get_employee(user.id)

        if not employee or not employee.get("active"):
            await update.message.reply_text(
                "Your account is not approved. Contact your administrator."
            )
            return ConversationHandler.END

        from datetime import date

        today = date.today().isoformat()

        context.user_data["report"] = {
            "report_date": today
        }
        context.user_data["activities_checklist"] = []
        context.user_data["service_checks"] = {}

        context.user_data.pop("current_activity", None)

        await update.message.reply_text(
            f"📅 Duty Date: {today}\n\n"
            "Step 1: Select your duty shift:",
            reply_markup=employee_shift_keyboard()
        )

        return SHIFT_SELECTION

    except Exception:
        logging.exception("Report authorization error")

        await update.message.reply_text(
            "Unable to start a report."
        )

        return ConversationHandler.END


async def start_time(update, context):
    value = update.message.text.strip()

    try:
        from datetime import datetime
        datetime.strptime(value, "%H:%M")
    except ValueError:
        await update.message.reply_text(
            "Use HH:MM format, for example 06:00."
        )
        return START_TIME

    context.user_data["report"]["duty_start"] = value

    await update.message.reply_text(
        "Enter your duty end time (HH:MM)."
    )

    return END_TIME


async def end_time(update, context):
    value = update.message.text.strip()
    try:
        from datetime import datetime
        datetime.strptime(value, "%H:%M")
    except ValueError:
        await update.message.reply_text(
            "Use HH:MM format, for example 15:00."
        )
        return END_TIME

    context.user_data["report"]["duty_end"] = value
    await update.message.reply_text(
        "Enter your first IT activity, for example: "
        "Troubleshoot cashier POS printer."
    )
    return ACTIVITY_DESCRIPTION
async def duty_date_input(update, context):
    from datetime import date

    text = update.message.text.strip()

    try:
        duty_date = date.fromisoformat(text)

        if duty_date > date.today():
            await update.message.reply_text(
                "Future duty dates are not allowed. Enter a valid date."
            )
            return DUTY_DATE

    except ValueError:
        await update.message.reply_text(
            "Invalid date format.\n"
            "Please use YYYY-MM-DD.\n"
            "Example: 2026-10-30"
        )
        return DUTY_DATE

    context.user_data["report"]["report_date"] = duty_date.isoformat()

    shifts = get_active_shifts()

    if not shifts:
        await update.message.reply_text(
            "No active duty shifts are configured. Contact your administrator."
        )
        return ConversationHandler.END

    await update.message.reply_text(
        f"📅 Duty date: {duty_date.isoformat()}\n\n"
        "Step 2: Select your duty shift:",
        reply_markup=employee_shift_keyboard()
    )

    return SHIFT_SELECTION
async def duty_shift_callback(update, context):
    query = update.callback_query
    await query.answer()

    try:
        employee = get_employee(query.from_user.id)

        if not employee or not employee.get("active"):
            await query.edit_message_text(
                "Your account is not approved."
            )
            return ConversationHandler.END

        report = context.user_data.get("report")

        if not report:
            await query.edit_message_text(
                "Report session expired. Please start again."
            )
            return ConversationHandler.END

        index = int(query.data.split(":")[1])
        shifts = get_active_shifts()

        if index < 0 or index >= len(shifts):
            await query.edit_message_text(
                "This shift is no longer available."
            )
            return ConversationHandler.END

        selected_shift = shifts[index]

        report["shift"] = selected_shift["name"]
        report["duty_start"] = selected_shift["start_time"]
        report["duty_end"] = selected_shift["end_time"]

        context.user_data["service_checks"] = {}

        await query.edit_message_text(
            f"Selected shift: {selected_shift['name']}\n"
            f"Duty time: {selected_shift['start_time']} - "
            f"{selected_shift['end_time']}"
        )

        await query.message.reply_text(
            "STEP 2 — SELECT REPORT LOCATION\n\n"
            "Where are you performing this duty?",
            reply_markup=report_location_keyboard()
        )

        return REPORT_LOCATION

    except Exception:
        logging.exception("Duty shift selection error")

        await query.message.reply_text(
            "Unable to select your shift. Please restart your report."
        )

        return ConversationHandler.END

def report_location_keyboard():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📍 Arrival", callback_data="report_location:Arrival")],
        [InlineKeyboardButton("📍 Departure", callback_data="report_location:Departure")],
        [InlineKeyboardButton("🏢 Office", callback_data="report_location:Office")],
    ])


async def report_location_callback(update, context):
    query = update.callback_query
    await query.answer()

    employee = get_employee(query.from_user.id)
    report = context.user_data.get("report")

    if not employee or not employee.get("active") or not report:
        await query.edit_message_text("Your report session is unavailable. Please start again.")
        return ConversationHandler.END

    location = query.data.split(":", 1)[1]

    if location not in ("Arrival", "Departure", "Office"):
        await query.answer("Invalid location.", show_alert=True)
        return REPORT_LOCATION

    report["report_location"] = location
    context.user_data["service_checks"] = {}

    await query.edit_message_text(
        f"Report location selected: {location}"
    )

    await query.message.reply_text(
        "STEP 2 — IT SERVICE CHECKLIST\n\n"
        "Select one status for each service.\n"
        "Your selections will be saved in the report.\n\n"
        f"Progress: 0/{len(get_service_options())}",
        reply_markup=service_checks_keyboard({})
    )

    return SERVICE_CHECKS


  
async def activities(update, context):
    context.user_data["report"]["activities"] = update.message.text.strip()
    await update.message.reply_text(
        "Describe technical problems encountered, or type None."
    )
    return PROBLEMS


async def problems(update, context):
    value = update.message.text.strip()
    context.user_data["report"]["problems"] = (
        None if value.lower() == "none" else value
    )
    await update.message.reply_text(
        "List pending tasks, or type None."
    )
    return PENDING


async def pending(update, context):
    value = update.message.text.strip()
    context.user_data["report"]["pending_tasks"] = (
        None if value.lower() == "none" else value
    )
    await update.message.reply_text(
        "Add any comments, or type None."
    )
    return COMMENTS


async def comments(update, context):
    value = update.message.text.strip()

    r = context.user_data["report"]

    r["comments"] = (
        None if value.lower() == "none" else value
    )

    service_summary = "\n".join(
        f"• {item['name']}: {item['status']}"
        for item in r.get("service_checks", [])
    )

    summary = (
        "📋 DAILY IT DUTY REPORT REVIEW\n\n"
        f"📅 Duty Date: {r.get('report_date', 'Not set')}\n"
        f"🕒 Shift: {r.get('shift', 'Not set')}\n"
        f"⏰ Duty Time: {r['duty_start']} - {r['duty_end']}\n\n"
        "🔧 SERVICE CHECKLIST\n"
        f"{service_summary or 'None'}\n\n"
        f"📝 Activities:\n{r['activities']}\n\n"
        f"⚠️ Problems: {r['problems'] or 'None'}\n"
        f"📌 Pending: {r['pending_tasks'] or 'None'}\n"
        f"💬 Comments: {r['comments'] or 'None'}\n\n"
        "Send /submit to save your report, or /cancel to discard."
    )

    await update.message.reply_text(summary)

    return CONFIRM

def create_report_pdf(report_id, employee, report):
    buffer = BytesIO()

    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=18 * mm,
        leftMargin=18 * mm,
        topMargin=18 * mm,
        bottomMargin=18 * mm
    )

    styles = getSampleStyleSheet()
    elements = []

    def safe(value):
        return escape(str(value if value is not None else "-")).replace(
            "\n", "<br/>"
        )

    elements.append(
        Paragraph("FLEMINGO DUTY FREE", styles["Title"])
    )
    elements.append(
        Paragraph("IT DAILY DUTY REPORT", styles["Heading2"])
    )
    elements.append(Spacer(1, 12))

    details = [
    ["Report ID", str(report_id)],
    ["Employee", employee.get("full_name", "Unknown")],
    ["Report Date", report.get("report_date", "N/A")],
    ["Shift", report.get("shift", "N/A")],
    ["Location", report.get("report_location", "N/A")],
    ["Duty Start", report.get("duty_start", "N/A")],
    ["Duty End", report.get("duty_end", "N/A")],
    ["Review Status", report.get("review_status", "pending")],
]

    table = Table(details, colWidths=[45 * mm, 115 * mm])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), colors.lightgrey),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("PADDING", (0, 0), (-1, -1), 7),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))

    elements.append(table)
    elements.append(Spacer(1, 15))

    sections = [
        ("Activities", report.get("activities")),
        ("Problems", report.get("problems")),
        ("Pending Tasks", report.get("pending_tasks")),
        ("Comments", report.get("comments")),
    ]

    for heading, content in sections:
        elements.append(Paragraph(heading, styles["Heading2"]))
        elements.append(
            Paragraph(safe(content), styles["BodyText"])
        )
        elements.append(Spacer(1, 10))

    doc.build(elements)

    buffer.seek(0)
    return buffer

def create_report_pdf(report_id, employee, report, activity_checklist):
    buffer = BytesIO()

    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=18 * mm,
        leftMargin=18 * mm,
        topMargin=18 * mm,
        bottomMargin=18 * mm
    )

    styles = getSampleStyleSheet()
    elements = []

    def make_paragraph(value, style="BodyText"):
        value = str(value if value is not None else "None")

        # Keep the built-in PDF font compatible with its character set.
        value = value.encode("latin-1", "replace").decode("latin-1")
        value = escape(value).replace("\n", "<br/>")

        return Paragraph(value, styles[style])

    elements.append(
        Paragraph("FLEMINGO DUTY FREE", styles["Title"])
    )
    elements.append(
        Paragraph("IT DAILY DUTY REPORT", styles["Heading2"])
    )
    elements.append(Spacer(1, 12))

    details = [
        ["Report ID", str(report_id)],
        ["Employee", employee.get("full_name", "Unknown")],
        ["Report Date", report.get("report_date", "N/A")],
        ["Shift", report.get("shift", "N/A")],
        ["Duty Start", report.get("duty_start", "N/A")],
        ["Duty End", report.get("duty_end", "N/A")],
    ]

    detail_table = Table(
        [
            [make_paragraph(row[0], "BodyText"),
             make_paragraph(row[1], "BodyText")]
            for row in details
        ],
        colWidths=[42 * mm, 118 * mm]
    )

    detail_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, -1), colors.lightgrey),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("PADDING", (0, 0), (-1, -1), 7),
    ]))

    elements.append(detail_table)
    elements.append(Spacer(1, 16))

    elements.append(
        Paragraph("SERVICE INSPECTION CHECKLIST", styles["Heading2"])
    )

    checklist_rows = [
        [
            make_paragraph("Service", "BodyText"),
            make_paragraph("Status", "BodyText")
        ]
    ]

    for item in report.get("service_checks", []):
        checklist_rows.append([
            make_paragraph(item.get("name", "Unknown")),
            make_paragraph(item.get("status", "N/A"))
        ])

    if len(checklist_rows) == 1:
        checklist_rows.append([
            make_paragraph("No checklist data"),
            make_paragraph("N/A")
        ])

    checklist_table = Table(
        checklist_rows,
        colWidths=[100 * mm, 60 * mm],
        repeatRows=1
    )

    checklist_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("PADDING", (0, 0), (-1, -1), 7),
    ]))

    elements.append(checklist_table)
    elements.append(Spacer(1, 14))

    sections = [
        ("IT ACTIVITIES", report.get("activities")),
        ("ACTIVITY CHECKLIST", activity_checklist),
        ("PROBLEMS REPORTED", report.get("problems")),
        ("PENDING TASKS", report.get("pending_tasks")),
        ("COMMENTS", report.get("comments")),
    ]

    for heading, content in sections:
        elements.append(
            Paragraph(heading, styles["Heading2"])
        )

        if isinstance(content, (list, dict)):
            content = json.dumps(content, indent=2, ensure_ascii=False)

        elements.append(make_paragraph(content))
        elements.append(Spacer(1, 10))

    elements.append(Spacer(1, 15))
    elements.append(
        Paragraph(
            "Flemingo IT Department | Internal Duty Report",
            styles["Italic"]
        )
    )

    doc.build(elements)

    buffer.seek(0)
    return buffer



async def submit(update, context):
    user = update.effective_user

    if not user or not update.message:
        return ConversationHandler.END

    try:
        employee = get_employee(user.id)

        if not employee or not employee.get("active"):
            await update.message.reply_text(
                "Your account is not approved."
            )
            return ConversationHandler.END

        r = context.user_data.get("report")

        if not r:
            await update.message.reply_text(
                "No report found. Use /report to begin."
            )
            return ConversationHandler.END

        required_fields = [
    "report_date",
    "shift",
    "report_location",
    "duty_start",
    "duty_end",
    "activities",
    "problems",
    "pending_tasks",
]

        if any(field not in r for field in required_fields):
            await update.message.reply_text(
                "Your report is incomplete. Please restart using /report."
            )
            return ConversationHandler.END

        service_checks = r.get("service_checks", [])

        service_summary = "\n".join(
            f"{item['name']}: {item['status']}"
            for item in service_checks
        ) or "None selected"

        activities_text = (
            f"SHIFT: {r['shift']}\n\n"
            f"SERVICE CHECKLIST:\n{service_summary}\n\n"
            f"ACTIVITIES:\n{r['activities']}"
        )

        checklist = context.user_data.get(
            "activities_checklist", []
        )

        result = get_db().table("daily_reports").insert({
    "report_date": r["report_date"],
    "employee_id": employee["id"],
    "duty_start": r["duty_start"],
    "duty_end": r["duty_end"],
    "shift": r["shift"],
    "report_location": r["report_location"],
    "activities": activities_text,
    "problems": r["problems"],
    "pending_tasks": r["pending_tasks"],
    "comments": r.get("comments"),
    "activities_checklist": checklist,
    "review_status": "pending",
}).select("id").execute()

        if not result.data:
            raise RuntimeError("No report ID returned by Supabase.")

        report_id = result.data[0]["id"]

        pdf_report = {
            "report_date": r["report_date"],
            "shift": r["shift"],
            "duty_start": r["duty_start"],
            "duty_end": r["duty_end"],
            "service_checks": service_checks,
            "activities": r.get("activities"),
            "problems": r.get("problems"),
            "pending_tasks": r.get("pending_tasks"),
            "comments": r.get("comments"),
            "report_location": r["report_location"],
            "review_status": "pending",
        }

        pdf_buffer = create_report_pdf(
            report_id,
            employee,
            pdf_report,
            checklist
        )

        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton(
                "✅ Mark as Reviewed",
                callback_data=f"review_report:{report_id}:{user.id}"
            )
        ]])

        try:
            await context.bot.send_document(
                chat_id=int(ADMIN_ID),
                document=InputFile(
                    pdf_buffer,
                    filename=f"Flemingo_IT_Report_{report_id}.pdf"
                ),
                caption=(
                    f"NEW DAILY IT DUTY REPORT\n"
                    f"Report ID: {report_id}\n"
                    f"Employee: {employee.get('full_name', 'Unknown')}\n"
                    f"Date: {r['report_date']}"
                ),
                reply_markup=keyboard
            )

        except Exception:
            logging.exception(
                "Report saved, but PDF notification failed."
            )

            await update.message.reply_text(
                "Your report was saved successfully, but the PDF "
                "could not be delivered to the administrator. "
                "Please contact the administrator."
            )

        else:
            await update.message.reply_text(
                "✅ Your daily report was submitted successfully.\n\n"
                "📄 PDF report generated and sent to the administrator "
                "for review."
            )

        context.user_data.pop("report", None)
        context.user_data.pop("activities_checklist", None)
        context.user_data.pop("service_checks", None)

    except Exception:
        logging.exception("Report submission error")

        await update.message.reply_text(
            "Unable to submit your report. Check the bot logs "
            "before retrying."
        )

    return ConversationHandler.END


async def cancel(update, context):
    context.user_data.pop("report", None)
    await update.message.reply_text("Report cancelled.")
    return ConversationHandler.END


async def help_command(update, context):
    await update.message.reply_text(
        "/start - Register or check account status\n"
        "/report - Start a daily report\n"
        "/submit - Save the completed report\n"
        "/cancel - Cancel a report\n"
        "/help - Show commands"
    )

ACTIVITY_STATUSES = [
    "Completed",
    "In progress",
    "Remaining",
]
async def approval_callback(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
):
    query = update.callback_query
    user = update.effective_user

    if not query:
        return

    if not user or str(user.id) != ADMIN_ID:
        await query.answer("You are not authorized.", show_alert=True)
        return

    await query.answer()

    try:
        action, telegram_id_text = query.data.split(":", 1)
        telegram_id = int(telegram_id_text)
        employee = get_employee(telegram_id)

        if not employee or employee.get("role") != "employee":
            await query.edit_message_text(
                "Employee registration was not found."
            )
            return

        if employee.get("active"):
            await query.edit_message_text(
                f"{employee.get('full_name', 'Employee')} is already approved."
            )
            return

        if action == "approve_employee":
            get_db().table("employees").update({
                "active": True,
            }).eq("telegram_id", telegram_id).execute()

            await query.edit_message_text(
                f"Approved: {employee.get('full_name', 'Employee')}."
            )

            await context.bot.send_message(
                chat_id=telegram_id,
                text=(
                    "Your account has been approved. "
                    "Send /start to begin using the Daily IT Duty Report Bot."
                ),
            )

        elif action == "reject_employee":
            # Remove only an inactive employee's pending registration.
            get_db().table("employees").delete().eq(
                "telegram_id", telegram_id
            ).eq("active", False).eq("role", "employee").execute()

            await query.edit_message_text(
                f"Registration rejected: "
                f"{employee.get('full_name', 'Employee')}. "
                "The account remains unapproved."
            )

            await context.bot.send_message(
                chat_id=telegram_id,
                text=(
                    "Your registration was not approved. "
                    "Contact the administrator if you believe this is an error."
                ),
            )

    except Exception:
        logging.exception("Approval action failed")
        await query.edit_message_text(
            "Unable to process this decision. Check the bot logs."
        )


async def report_review_callback(update, context):
    query = update.callback_query
    user = update.effective_user

    if not query:
        return

    if not user or not is_admin_user(user.id):
        await query.answer("You are not authorized.", show_alert=True)
        return

    await query.answer()

    try:
        _, report_id_text, employee_telegram_id_text = query.data.split(":", 2)

        report_id = int(report_id_text)
        employee_telegram_id = int(employee_telegram_id_text)

        db = get_db()

        report_result = (
            db.table("daily_reports")
            .select("id, employee_id, review_status")
            .eq("id", report_id)
            .limit(1)
            .execute()
        )

        if not report_result.data:
            await query.message.reply_text("Report not found.")
            return

        report = report_result.data[0]

        employee_result = (
            db.table("employees")
            .select("id, telegram_id")
            .eq("id", report["employee_id"])
            .limit(1)
            .execute()
        )

        if not employee_result.data:
            await query.message.reply_text("Report employee not found.")
            return

        employee = employee_result.data[0]

        if int(employee["telegram_id"]) != employee_telegram_id:
            await query.message.reply_text("Employee verification failed.")
            return

        db.table("daily_reports").update({
            "review_status": "reviewed",
            "reviewed_by": user.id,
            "reviewed_at": datetime.now(timezone.utc).isoformat()
        }).eq("id", report_id).execute()

        await query.edit_message_reply_markup(reply_markup=None)

        await query.message.reply_text(
            f"Report {report_id} marked as reviewed."
        )

        await context.bot.send_message(
            chat_id=employee_telegram_id,
            text=(
                f"Your Daily IT Duty Report #{report_id} "
                "has been reviewed by the administrator."
            )
        )

    except Exception:
        logging.exception("Report review update failed")
        await query.message.reply_text(
            "Unable to update the review status. Check the bot logs."
        )

    
conversation = ConversationHandler(
    entry_points=[
        CommandHandler("report", report_start),
        MessageHandler(
            filters.Regex("^📝 Start Daily Report$"),
            report_start,
        ),
    ],
    states={
        DUTY_DATE: [
            MessageHandler(
                filters.TEXT & ~filters.COMMAND,
                duty_date_input,
            )
        ],

        REPORT_LOCATION: [
            CallbackQueryHandler(
                report_location_callback,
                pattern=r"^report_location:",
            )
        ],

        SHIFT_SELECTION: [
            CallbackQueryHandler(
                duty_shift_callback,
                pattern=r"^duty_shift:",
            )
        ],

        SERVICE_CHECKS: [
            CallbackQueryHandler(
                service_checks_callback,
                pattern=r"^(service_status:|service_info:)",
            )
        ],

        START_TIME: [
            MessageHandler(
                filters.TEXT & ~filters.COMMAND,
                start_time,
            )
        ],

        END_TIME: [
            MessageHandler(
                filters.TEXT & ~filters.COMMAND,
                end_time,
            )
        ],

        ACTIVITY_DESCRIPTION: [
            MessageHandler(
                filters.TEXT & ~filters.COMMAND,
                activity_description,
            )
        ],

        ACTIVITY_STATUS: [
            CallbackQueryHandler(
                activity_status,
                pattern=r"^activity_status:",
            )
        ],

        ACTIVITY_REASON: [
            MessageHandler(
                filters.TEXT & ~filters.COMMAND,
                activity_reason,
            )
        ],

        ACTIVITY_NEXT_ACTION: [
            MessageHandler(
                filters.TEXT & ~filters.COMMAND,
                activity_next_action,
            )
        ],

        ACTIVITY_MORE: [
            CallbackQueryHandler(
                activity_more,
                pattern=r"^activity_more:",
            )
        ],

        PROBLEMS: [
            MessageHandler(
                filters.TEXT & ~filters.COMMAND,
                problems,
            )
        ],

        PENDING: [
            MessageHandler(
                filters.TEXT & ~filters.COMMAND,
                pending,
            )
        ],

        COMMENTS: [
            MessageHandler(
                filters.TEXT & ~filters.COMMAND,
                comments,
            )
        ],

        CONFIRM: [
            CommandHandler("submit", submit)
        ],
    },

    fallbacks=[
        CommandHandler("cancel", cancel)
    ],
)



async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    if not user or not update.message:
        return

    tid = user.id
    name = user.full_name

    try:
        employee = get_employee(tid)

        # Register or update the configured administrator
        if str(tid) == str(ADMIN_ID):
            if employee:
                get_db().table("employees").update({
                    "full_name": name,
                    "role": "admin",
                    "active": True,
                }).eq("telegram_id", tid).execute()
            else:
                get_db().table("employees").insert({
                    "telegram_id": tid,
                    "full_name": name,
                    "role": "admin",
                    "active": True,
                }).execute()

            if await send_start_announcement(tid, context):
                return

            await show_user_dashboard(tid, user, context)
            return

        # Register a new employee
        if not employee:
            get_db().table("employees").insert({
                "telegram_id": tid,
                "full_name": name,
                "role": "employee",
                "active": False,
            }).execute()

            keyboard = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton(
                        "Approve",
                        callback_data=f"approve_employee:{tid}",
                    ),
                    InlineKeyboardButton(
                        "Reject",
                        callback_data=f"reject_employee:{tid}",
                    ),
                ]
            ])

            try:
                await context.bot.send_message(
                    chat_id=int(ADMIN_ID),
                    text=(
                        "🔔 New employee registration\n\n"
                        f"Name: {name}\n"
                        f"Telegram ID: {tid}\n\n"
                        "Approve or reject this account:"
                    ),
                    reply_markup=keyboard,
                )
            except Exception:
                logging.exception(
                    "Could not notify administrator"
                )

            await update.message.reply_text(
                "⏳ Your registration request has been recorded.\n\n"
                "An administrator must approve your account "
                "before you can submit reports."
            )
            return

        # Check employee approval
        if not employee.get("active"):
            await update.message.reply_text(
                "⏳ Your account is awaiting administrator approval."
            )
            return

        # Show announcement before employee dashboard
        if await send_start_announcement(tid, context):
            return

        # Show employee dashboard
        await show_user_dashboard(tid, user, context)

    except Exception:
        logging.exception("Registration error")
        await update.message.reply_text(
            "Unable to process your request. Please try again later."
        )

    return ConversationHandler.END

async def pending_approvals(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not user or str(user.id) != ADMIN_ID:
        if update.message:
            await update.message.reply_text("You are not authorized.")
        return

    if not update.message:
        return

    try:
        result = (
            get_db().table("employees")
            .select("telegram_id, full_name")
            .eq("role", "employee")
            .eq("active", False)
            .execute()
        )
        employees = result.data or []

        if not employees:
            await update.message.reply_text("There are no pending registrations.")
            return

        for emp in employees:
            tid = emp["telegram_id"]
            name = emp.get("full_name") or "Unknown employee"
            keyboard = InlineKeyboardMarkup([[
                InlineKeyboardButton("Approve", callback_data=f"approve_employee:{tid}"),
                InlineKeyboardButton("Reject", callback_data=f"reject_employee:{tid}"),
            ]])
            await update.message.reply_text(
                f"Employee: {name}\nTelegram ID: {tid}",
                reply_markup=keyboard,
            )
    except Exception:
        logging.exception("Could not load pending registrations")
        await update.message.reply_text("Could not load registrations. Check bot logs.")

async def report_search_start(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE
):
    if not is_admin_user(update.effective_user.id):
        await update.message.reply_text(
            "Unauthorized access."
        )
        return ConversationHandler.END

    await update.message.reply_text(
        "🔎 SEARCH REPORTS\n\n"
        "Enter an employee name, Telegram ID, "
        "or report date to search.\n\n"
        "Example: 2026-10-30\n\n"
        "Send /cancel to stop."
    )

    return SEARCH_REPORT_QUERY

async def delete_report_prompt(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer("Unauthorized access.", show_alert=True)
        return

    report_id = query.data.split(":", 1)[1]

    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "🗑 YES, DELETE REPORT",
                callback_data=f"confirm_delete_report:{report_id}"
            )
        ],
        [
            InlineKeyboardButton(
                "↩️ Cancel",
                callback_data=f"cancel_delete_report:{report_id}"
            )
        ]
    ])

    await query.answer()

    await query.edit_message_reply_markup(
        reply_markup=keyboard
    )


async def confirm_delete_report(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer("Unauthorized access.", show_alert=True)
        return

    report_id = query.data.split(":", 1)[1]

    try:
        db = get_db()

        existing = (
            db.table("daily_reports")
            .select("id")
            .eq("id", report_id)
            .limit(1)
            .execute()
        )

        if not existing.data:
            await query.answer(
                "Report not found. It may already be deleted.",
                show_alert=True
            )
            return

        db.table("daily_reports").delete().eq(
            "id", report_id
        ).execute()

        await query.answer("Report deleted successfully.")

        await query.edit_message_text(
            f"🗑 REPORT DELETED\n\n"
            f"Report ID: {report_id}\n"
            f"Deleted by administrator: {query.from_user.id}"
        )

    except Exception:
        logging.exception("Report deletion failed")

        await query.answer(
            "Unable to delete report. Check Supabase permissions.",
            show_alert=True
        )


async def cancel_delete_report(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer("Unauthorized access.", show_alert=True)
        return

    await query.answer("Deletion cancelled.")

    await query.edit_message_reply_markup(
        reply_markup=None
    )


async def report_search_query(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE
):
    if not is_admin_user(update.effective_user.id):
        await update.message.reply_text("Unauthorized access.")
        return ConversationHandler.END

    search_text = update.message.text.strip()

    if not search_text:
        await update.message.reply_text(
            "Please enter an employee name, Telegram ID, or date."
        )
        return SEARCH_REPORT_QUERY

    try:
        db = get_db()

        reports_response = (
            db.table("daily_reports")
            .select("*")
            .order("report_date", desc=True)
            .limit(200)
            .execute()
        )

        employees_response = (
            db.table("employees")
            .select("id, full_name, telegram_id")
            .execute()
        )

        employees = {
            str(emp["id"]): emp
            for emp in employees_response.data
        }

        search_lower = search_text.lower()
        matching_reports = []

        for report in reports_response.data:
            employee = employees.get(
                str(report.get("employee_id")), {}
            )

            employee_name = str(employee.get("full_name", ""))
            telegram_id = str(employee.get("telegram_id", ""))
            report_date = str(report.get("report_date", ""))

            if (
                search_lower in employee_name.lower()
                or search_lower in telegram_id
                or search_lower == report_date
            ):
                matching_reports.append((report, employee))

        if not matching_reports:
            await update.message.reply_text(
                "🔎 No matching reports found.\n\n"
                "Try an employee name, Telegram ID, "
                "or date in YYYY-MM-DD format."
            )
            return ConversationHandler.END

        for report, employee in matching_reports[:10]:
            report_id = report.get("id")

            message = (
                "📋 DAILY IT REPORT\n"
                "━━━━━━━━━━━━━━━━━━\n"
                f"🆔 Report ID: {report_id}\n"
                f"👤 Employee: {employee.get('full_name', 'Unknown')}\n"
                f"🆔 Telegram ID: {employee.get('telegram_id', 'N/A')}\n"
                f"📅 Date: {report.get('report_date', 'N/A')}\n"
                f"🕕 Start: {report.get('duty_start', 'N/A')}\n"
                f"🕒 End: {report.get('duty_end', 'N/A')}\n\n"
                f"📝 Activities:\n"
                f"{report.get('activities', 'None')}\n\n"
                f"⚠️ Problems:\n"
                f"{report.get('problems', 'None')}\n\n"
                f"📌 Pending Tasks:\n"
                f"{report.get('pending_tasks', 'None')}\n\n"
                f"💬 Comments:\n"
                f"{report.get('comments', 'None')}"
                f"📍 Location: {report.get('report_location') or 'N/A'}\n"
                f"📋 Review: {(report.get('review_status') or 'pending').title()}\n"
            )

            keyboard = InlineKeyboardMarkup([[
                InlineKeyboardButton(
                    "🗑 Delete Report",
                    callback_data=f"delete_report_prompt:{report_id}"
                )
            ]])

            await update.message.reply_text(
                message[:4000],
                reply_markup=keyboard
            )

        if len(matching_reports) > 10:
            await update.message.reply_text(
                f"Showing 10 of {len(matching_reports)} matching reports."
            )

    except Exception:
        logging.exception("Report search failed")

        await update.message.reply_text(
            "Unable to search reports. Please try again."
        )

    return ConversationHandler.END


search_reports_conversation = ConversationHandler(
    entry_points=[
        MessageHandler(
            filters.Regex(r"^🔎 Search Reports$"),
            report_search_start,
        )
    ],
    states={
        SEARCH_REPORT_QUERY: [
            MessageHandler(
                filters.TEXT & ~filters.COMMAND,
                report_search_query,
            )
        ]
    },
    fallbacks=[CommandHandler("cancel", cancel)],
)





def is_admin_user(user_id):
    try:
        if str(user_id) == str(ADMIN_ID):
            return True

        employee = get_employee(user_id)

        return (
            employee is not None
            and employee.get("active") is True
            and employee.get("role") == "admin"
        )
    except Exception:
        logging.exception("Admin authorization check failed")
        return False
   
def get_checklist_settings():
    settings = get_bot_setting(
        "service_checklist",
        {
            "items": [
                {"name": name, "enabled": True}
                for name in DEFAULT_SERVICE_OPTIONS
            ]
        }
    )

    if isinstance(settings, list):
        items = settings
    elif isinstance(settings, dict):
        items = settings.get("items", [])
    else:
        items = []

    return {"items": items}


def save_checklist_settings(items, admin_id):
    return save_bot_setting(
        "service_checklist",
        {"items": items},
        admin_id
    )


def admin_checklist_keyboard():
    settings = get_checklist_settings()
    items = settings.get("items", [])

    rows = []

    for index, item in enumerate(items):
        status = "🟢" if item.get("enabled", True) else "🔴"

        rows.append([
            InlineKeyboardButton(
                f"{status} {item['name']}",
                callback_data=f"checklist_manage:{index}"
            )
        ])

    rows.append([
        InlineKeyboardButton(
            "➕ Add Service",
            callback_data="checklist_add"
        )
    ])

    rows.append([
        InlineKeyboardButton(
            "🔄 Refresh",
            callback_data="checklist_refresh"
        )
    ])

    rows.append([
        InlineKeyboardButton(
            "⬅️ Back to Settings",
            callback_data="admin_settings_back"
        )
    ])

    return InlineKeyboardMarkup(rows)


async def show_admin_checklist(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer(
            "Unauthorized access.",
            show_alert=True
        )
        return

    await query.answer()

    await query.edit_message_text(
        "⚙️ ADMIN CHECKLIST MANAGER\n\n"
        "Select an item to edit, or add a new checklist item.\n\n"
        "🟢 Enabled\n"
        "🔴 Disabled",
        reply_markup=admin_checklist_keyboard()
    )
    
async def checklist_refresh(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer(
            "Unauthorized access.",
            show_alert=True
        )
        return

    await query.answer("Checklist refreshed")

    await query.edit_message_reply_markup(
        reply_markup=admin_checklist_keyboard()
    )

async def checklist_manage_item(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer(
            "Unauthorized access.",
            show_alert=True
        )
        return

    await query.answer()

    index = int(query.data.split(":")[1])
    settings = get_checklist_settings()
    items = settings.get("items", [])

    if index < 0 or index >= len(items):
        await query.edit_message_text("Checklist item not found.")
        return

    item = items[index]
    name = item["name"]

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton(
            "✏️ Rename",
            callback_data=f"checklist_rename:{index}"
        )],
        [InlineKeyboardButton(
            "🔄 Enable / Disable",
            callback_data=f"checklist_toggle:{index}"
        )],
        [InlineKeyboardButton(
            "🗑 Delete",
            callback_data=f"checklist_delete:{index}"
        )],
        [InlineKeyboardButton(
            "⬅️ Back",
            callback_data="checklist_refresh"
        )]
    ])

    await query.edit_message_text(
        f"📋 CHECKLIST ITEM\n\n"
        f"Name: {name}\n"
        f"Status: {'Enabled' if item.get('enabled', True) else 'Disabled'}",
        reply_markup=keyboard
    )
    
async def checklist_toggle_item(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer(
            "Unauthorized access.",
            show_alert=True
        )
        return

    await query.answer()

    index = int(query.data.split(":")[1])
    settings = get_checklist_settings()
    items = settings.get("items", [])

    if index < 0 or index >= len(items):
        await query.edit_message_text("Checklist item not found.")
        return

    items[index]["enabled"] = not items[index].get("enabled", True)

    if save_checklist_settings(items, query.from_user.id):
        await query.edit_message_text(
            "✅ Checklist status updated.",
            reply_markup=admin_checklist_keyboard()
        )
    else:
        await query.edit_message_text(
            "Unable to save checklist changes. Please try again."
        )
        
async def checklist_delete_item(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer(
            "Unauthorized access.",
            show_alert=True
        )
        return

    await query.answer()

    index = int(query.data.split(":")[1])
    settings = get_checklist_settings()
    items = settings.get("items", [])

    if index < 0 or index >= len(items):
        await query.edit_message_text("Checklist item not found.")
        return

    deleted_name = items[index]["name"]
    items.pop(index)

    if save_checklist_settings(items, query.from_user.id):
        await query.edit_message_text(
            f"✅ Checklist item deleted: {deleted_name}",
            reply_markup=admin_checklist_keyboard()
        )
    else:
        await query.edit_message_text(
            "Unable to delete checklist item. Please try again."
        )
        
async def checklist_add_item(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer(
            "Unauthorized access.",
            show_alert=True
        )
        return

    await query.answer()

    context.user_data["checklist_action"] = "add"

    await query.message.reply_text(
        "➕ Enter the name of the new checklist item:"
    )
    
async def checklist_rename_item(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer(
            "Unauthorized access.",
            show_alert=True
        )
        return

    await query.answer()

    index = int(query.data.split(":")[1])
    settings = get_checklist_settings()
    items = settings.get("items", [])

    if index < 0 or index >= len(items):
        await query.edit_message_text("Checklist item not found.")
        return

    context.user_data["checklist_action"] = "rename"
    context.user_data["checklist_index"] = index

    await query.message.reply_text(
        f"✏️ Enter the new name for '{items[index]['name']}':"
    )
    
async def checklist_text_input(update, context):
    action = context.user_data.get("checklist_action")

    if not action or not update.message:
        return

    if not is_admin_user(update.effective_user.id):
        await update.message.reply_text("Unauthorized access.")
        context.user_data.pop("checklist_action", None)
        context.user_data.pop("checklist_index", None)
        return

    name = update.message.text.strip()

    if not name or len(name) > 80:
        await update.message.reply_text(
            "Please enter a name between 1 and 80 characters."
        )
        return

    settings = get_checklist_settings()
    items = settings.get("items", [])

    if any(
        item["name"].lower() == name.lower()
        for item in items
        if action == "add" or item != items[
            context.user_data.get("checklist_index", -1)
        ]
    ):
        await update.message.reply_text(
            "That checklist item already exists."
        )
        return

    if action == "add":
        items.append({"name": name, "enabled": True})

    elif action == "rename":
        index = context.user_data.get("checklist_index")

        if index is None or index < 0 or index >= len(items):
            await update.message.reply_text(
                "Checklist item not found."
            )
            return

        items[index]["name"] = name

    if save_checklist_settings(items, update.effective_user.id):
        context.user_data.pop("checklist_action", None)
        context.user_data.pop("checklist_index", None)

        await update.message.reply_text(
            "✅ Checklist updated successfully.",
            reply_markup=admin_checklist_keyboard()
        )
    else:
        await update.message.reply_text(
            "Unable to save checklist changes. Please try again."
        )

async def announcement_continue(update, context):
    query = update.callback_query
    await query.answer()

    user = query.from_user
    employee = get_employee(user.id)

    # Verify account approval
    if not employee or not employee.get("active"):
        await query.edit_message_text(
            "Your account is not currently approved. "
            "Please contact the administrator."
        )
        return

    # Remove the Continue button
    await query.edit_message_reply_markup(
        reply_markup=None
    )

    # Open the correct dashboard
    await show_user_dashboard(
        chat_id=query.message.chat_id,
        user=user,
        context=context,
    )
async def admin_text_input(update, context):
    if context.user_data.get("shift_action"):
        await shift_text_input(update, context)
        return

    if context.user_data.get("checklist_action"):
        await checklist_text_input(update, context)
        return

    if context.user_data.get("profile_action"):
        await profile_text_input(update, context)
        return

    if context.user_data.get("guideline_action"):
        await guideline_text_input(update, context)
        return

async def admin_settings_back(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer("Unauthorized.", show_alert=True)
        return

    await query.answer()

    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton(
                "📋 Manage Service Checklist",
                callback_data="checklist_admin"
            )
        ],
        [
            InlineKeyboardButton(
                "🕒 Manage Duty Shifts",
                callback_data="shift_manager"
            )
        ],
        [
            InlineKeyboardButton(
                "📚 Manage IT Guidelines",
                callback_data="guideline_admin"
            )
        ],
        [
            InlineKeyboardButton(
                "📊 Reports Analytics",
                callback_data="reports_analytics"
            )
        ]
    ])

    await query.edit_message_text(
        "⚙️ ADMIN SETTINGS\n\n"
        "Manage your IT reporting system:",
        reply_markup=keyboard
    )
async def reports_analytics(update, context):
    query = update.callback_query

    if not is_admin_user(query.from_user.id):
        await query.answer("Unauthorized.", show_alert=True)
        return

    await query.answer()

    try:
        from datetime import date

        today = date.today()
        today_text = today.isoformat()
        month_text = today.strftime("%Y-%m")

        # Retrieve recent reports
        result = (
            get_db()
            .table("daily_reports")
            .select("report_date, employee_id")
            .order("report_date", desc=True)
            .limit(1000)
            .execute()
        )

        reports = result.data or []

        # Retrieve employees
        employee_result = (
            get_db()
            .table("employees")
            .select("id")
            .execute()
        )

        employees = employee_result.data or []

        today_reports = [
            r for r in reports
            if str(r.get("report_date", ""))[:10] == today_text
        ]

        month_reports = [
            r for r in reports
            if str(r.get("report_date", "")).startswith(month_text)
        ]

        employees_reported = {
            r.get("employee_id")
            for r in month_reports
            if r.get("employee_id") is not None
        }

        total_employees = len(employees)
        reporting_employees = len(employees_reported)

        pending_employees = max(
            0,
            total_employees - reporting_employees
        )

        report_text = (
            "📊 REPORTS ANALYTICS\n\n"
            f"📅 Date: {today_text}\n"
            f"📆 Month: {today.strftime('%B %Y')}\n\n"
            "TODAY'S REPORTS\n"
            f"📝 Submitted: {len(today_reports)}\n\n"
            "MONTHLY PERFORMANCE\n"
            f"📋 Total reports: {len(month_reports)}\n"
            f"👥 Active employees reporting: {reporting_employees}\n"
            f"⏳ Employees not yet reporting: {pending_employees}\n"
            f"👤 Total registered employees: {total_employees}\n\n"
            "Internal IT Operations"
        )

        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton(
                    "🔄 Refresh",
                    callback_data="reports_analytics"
                )
            ],
            [
                InlineKeyboardButton(
                    "⬅️ Back to Settings",
                    callback_data="admin_settings_back"
                )
            ]
        ])

        await query.edit_message_text(
            report_text,
            reply_markup=keyboard
        )

    except Exception:
        logging.exception("Reports analytics error")

        await query.edit_message_text(
            "Unable to load reports analytics. "
            "Please check the server logs."
        )
       
def main():
    if not all([BOT_TOKEN, SUPABASE_URL, SUPABASE_KEY, ADMIN_ID]):
        raise RuntimeError("Required environment variables are missing.")

    app = Application.builder().token(BOT_TOKEN).build()

    # ==========================================
    # GENERAL COMMANDS
    # ==========================================

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("approvals", pending_approvals))

    app.add_handler(
        MessageHandler(
            filters.Regex(r"^📋 Admin Approval$"),
            pending_approvals
        )
    )


    CallbackQueryHandler(
        shift_change,
        pattern=r"^(shift_toggle|shift_delete|shift_rename):\d+$"
    )
 
     
    # ==========================================
    # EMPLOYEE FEATURES
    # ==========================================

    app.add_handler(
        MessageHandler(
            filters.Regex(r"^📁 My Reports$"),
            my_reports
        )
    )

    app.add_handler(
        MessageHandler(
            filters.Regex(r"^👤 My Profile$"),
            show_profile
        )
    )

    app.add_handler(
        MessageHandler(
            filters.Regex(r"^📚 IT Guidelines$"),
            show_guidelines
        )
    )

    # ==========================================
    # DAILY REPORT CONVERSATION
    # ==========================================

    app.add_handler(conversation)

    # ==========================================
    # ADMIN TEXT INPUT
    # ==========================================

    app.add_handler(
        MessageHandler(
            filters.TEXT & ~filters.COMMAND,
            admin_text_input
        ),
        group=1
    )

    # ==========================================
    # ANNOUNCEMENTS
    # ==========================================

    app.add_handler(
        CallbackQueryHandler(
            announcement_continue,
            pattern=r"^announcement_continue$"
        )
    )

    # ==========================================
    # DELETE REPORT
    # ==========================================

    app.add_handler(
        CallbackQueryHandler(
            delete_report_prompt,
            pattern=r"^delete_report_prompt:.+$"
        )
    )


    app.add_handler(
        CallbackQueryHandler(
            confirm_delete_report,
            pattern=r"^confirm_delete_report:.+$"
        )
    )

    app.add_handler(
        CallbackQueryHandler(
            cancel_delete_report,
            pattern=r"^cancel_delete_report:.+$"
        )
    )
         # Employee approval and rejection buttons
    app.add_handler(
        CallbackQueryHandler(
            approval_callback,
            pattern=r"^(approve_employee|reject_employee):\d+$"
        )
    )

    # ==========================================
    # START BOT
    # ==========================================

    logging.info("Flemingo IT Daily Report Bot started.")
    # ==========================================
 
        # ==========================================
    # MY REPORTS AND PROFILE
    # ==========================================

    app.add_handler(
        MessageHandler(
            filters.Regex(r"^📁 My Reports$"),
            my_reports
        )
    )

    app.add_handler(
        MessageHandler(
            filters.Regex(r"^👤 My Profile$"),
            show_profile
        )
    )

    # ==========================================
    # PROFILE CALLBACKS
    # ==========================================

    app.add_handler(
        CallbackQueryHandler(
            profile_edit_callback,
            pattern=r"^profile_edit:"
        )
    )

    # ==========================================
    # IT GUIDELINES CALLBACKS
    # ==========================================

    app.add_handler(
        CallbackQueryHandler(
            guideline_admin_menu,
            pattern=r"^guideline_admin$"
        )
    )

    app.add_handler(
        CallbackQueryHandler(
            guideline_add,
            pattern=r"^guideline_add$"
        )
    )

    app.add_handler(
        CallbackQueryHandler(
            guideline_manage,
            pattern=r"^guideline_manage:\d+$"
        )
    )

    app.add_handler(
        CallbackQueryHandler(
            guideline_edit_start,
            pattern=r"^guideline_edit:\d+:(title|category|content)$"
        )
    )

    app.add_handler(
        CallbackQueryHandler(
            guideline_publish_toggle,
            pattern=r"^guideline_publish:\d+$"
        )
    )

    app.add_handler(
        CallbackQueryHandler(
            guideline_active_toggle,
            pattern=r"^guideline_active:\d+$"
        )
    )

    app.add_handler(
        CallbackQueryHandler(
            guideline_view,
            pattern=r"^guideline_view:\d+$"
        )
    )

    app.add_handler(
        CallbackQueryHandler(
            guidelines_back,
            pattern=r"^guidelines_back$"
        )
    )

       # ==========================================
    # START BOT
    # ==========================================

    logging.info("Flemingo IT Daily Report Bot started.")

    app.run_polling()


if __name__ == "__main__":
    main()
